import 'dart:io';

void main(List<String> arguments) {

  print("Digite o valor da compra: ");
  double valor = double.parse(stdin.readLineSync()!);


  print("Digite o nivel do cliente  (1, 2 ou 3) -> 1(func), 2(vip) e 3(comum): ");
  int option = int.parse(stdin.readLineSync()!);
  switch (option) {
    case 1:
      print("Total a pagar (funcionario): ${valor * 0.9}");
      break;
    case 2:
      print("Total a pagar (vip): ${valor * 0.95}");
      break;
    case 3:
      print("Total a pagar (comum): $valor");
      break;
    default:
      print("Tipo de Cliente indisponivel");
      break;
  }
  
}