import 'dart:io';
// import 'package:intl/intl.dart'
// import 'dart:convert';
// import 'dart:math';

void main(List<String> arguments) {
  print("\x1B[2J\x1B[0;0H");

  const double pi = 3.14159265358979323846;

  DateTime data = DateTime.now();

  int option = 1;

  while (option != 0){
    print(
        "Digite função da aplicação -> \n 1-Somar  \n 2-Subtração  \n 3-Multiplicação  \n 4-Divisão  \n 5-Calcular Retângulo  \n 6-Calcular Triângulo  \n 7-Calcular Raio  \n 8-Calcular Idade \n 0-Sair");
    option = int.parse(stdin.readLineSync()!);

    switch (option) {
      case 1:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira um numero: ");
        double num1 = double.parse(stdin.readLineSync()!);
        print("Insira outro numero: ");
        double num2 = double.parse(stdin.readLineSync()!);
        String result = (num1 + num2).toStringAsFixed(2);
        print("$nome o Resultado da Soma é: $result.runtimeType");
        break;
      case 2:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira um numero: ");
        double num1 = double.parse(stdin.readLineSync()!);
        print("Insira outro numero: ");
        double num2 = double.parse(stdin.readLineSync()!);
        String result = (num1 - num2).toStringAsFixed(2);
        print(
            "$nome a Subtração do numero $num1 pelo numero $num2 é: $result.runtimeType");
        break;
      case 3:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira um numero: ");
        double num1 = double.parse(stdin.readLineSync()!);
        print("Insira outro numero: ");
        double num2 = double.parse(stdin.readLineSync()!);
        String result = (num1 * num2).toStringAsFixed(2);
        print("$nome o Resultado da Multiplicação é: $result.runtimeType");
        break;
      case 4:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira o numero dividendo: ");
        double num1 = double.parse(stdin.readLineSync()!);
        print("Insira o numero divisor: ");
        double num2 = double.parse(stdin.readLineSync()!);
        String result = (num1 / num2).toStringAsFixed(2);
        print(
            "$nome a divisão do numero $num1 por $num2 é: $result.runtimeType");
        break;
      case 5:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira o comprimento do retângulo: ");
        double num1 = double.parse(stdin.readLineSync()!);
        print("Insira a largura do retângulo:  ");
        double num2 = double.parse(stdin.readLineSync()!);
        String result = (num1 * num2).toStringAsFixed(2);
        print("$nome a area do retângulo é: $result.runtimeType");
        break;
      case 6:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira o comprimento da base do triângulo: ");
        double num1 = double.parse(stdin.readLineSync()!);
        print("Insira a altura do triângulo: ");
        double num2 = double.parse(stdin.readLineSync()!);
        String result = ((num1 * num2) / 2).toStringAsFixed(2);
        print("$nome a area do triângulo é: $result.runtimeType");
        break;
      case 7:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print("Insira o comprimento da circunferência: ");
        double num1 = double.parse(stdin.readLineSync()!);
        String result = ((num1 / pi) / 2).toStringAsFixed(2);
        print("$nome o raio da circunferencia é: $result.runtimeType");
        break;
      case 8:
        print("Digite seu nome: ");
        String? nome = stdin.readLineSync();
        print(
            "Insira sua data de nascimento em numeros no formato aaaaMMdd [Exemplo: 25/12/2000 fica 20001225]: ");
        DateTime nasc = DateTime.parse(stdin.readLineSync()!);
        int anoDif = data.year - nasc.year;
        int mesDif = data.month - nasc.month;
        int diaDif = data.day - nasc.day;
        int dias = 0;
        int mes = 0;
        int meses = 0;
        int ano = 0;
        int anos = 0;

        if (diaDif < 0) {
          dias = 30 + diaDif;
          meses = mesDif - 1;
          anos = anoDif;
          if (meses < 0) {
            meses = meses + 12;
            anos = ano - 1;
          }
        } else {
          dias = diaDif;
          meses = mesDif;
          anos = anoDif;
        }
        print(
            '$nome você tem $anos ano(s), $meses mese(s) e $dias dia(s) de vida! ');
        break;
      default:
        if (option == 0) {
          break;
        } else {
          print("Tipo de função indisponivel");
        }
        break;
    }
  }
}
