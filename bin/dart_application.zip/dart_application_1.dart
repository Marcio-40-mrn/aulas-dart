import 'dart:convert';
import 'dart:io';

void main(List<String> arguments) {
//Recebe valor do eixo X
  print("Digite o valor do Eixo X:");
  int x = int.parse(stdin.readLineSync(encoding: utf8)!);

//Recebe valor do eixo y
  print("Digite o valor do Eixo Y:");
  int y = int.parse(stdin.readLineSync(encoding: utf8)!);

  if (x > 0 && y > 0) {
    print("Valor pertence ao Qaundrante 1");
  } else if (x < 0 && y > 0) {
    print("Valor pertence ao quadrante 2");
  } else if (x < 0 && y < 0) {
    print("Valor pertence ao quadrante 3");
  } else if (x > 0 && y < 0) {
    print("Valor pertence ao quadrante 4");
  }
}
